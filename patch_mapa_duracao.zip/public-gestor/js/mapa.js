// ─── mapa.js ──────────────────────────────────────────────────────────────────
// Mapa operacional com filtros: cidade, operação, vínculo, cargo

const mapaScreen = (() => {
  let _map = null;
  let _interval = null;
  let _layerPromotores = null;
  let _layerSlots = null;
  let _layerRaios = null;
  let _layerRota = null;

  let _todosPromotores = [];
  let _todosSlots = [];

  const _visible = { promotores: true, slots: true, raios: true, rota: true };

  // Filtros ativos
  const _filtros = {
    cidade: '',
    operacao: '',
    vinculo: '',   // MEI | CLT | ''
    cargo: '',
  };

  // ── Render ───────────────────────────────────────────────────────────────────
  function render() {
    const app = document.getElementById('app');
    app.innerHTML = `
      <section class="screen screen-map" id="screen-mapa" style="display:flex;flex-direction:column;height:100%">

        <!-- Toolbar principal -->
        <div class="map-toolbar" style="flex-direction:column;gap:8px;padding:10px 16px">
          <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <span class="map-title">Mapa Operacional</span>
            <div class="map-toggles">
              <button class="toggle-btn active" data-layer="promotores">👤 Pessoas</button>
              <button class="toggle-btn active" data-layer="slots">📍 Slots</button>
              <button class="toggle-btn active" data-layer="raios">⭕ Raios</button>
              <button class="toggle-btn active" data-layer="rota">🛣️ Rota</button>
            </div>
            <span id="mapa-updated" class="map-updated" style="margin-left:auto">—</span>
          </div>

          <!-- Filtros -->
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <select id="filtro-vinculo" style="background:#0d1526;border:1px solid rgba(99,179,237,.2);color:#e2e8f0;padding:5px 10px;border-radius:4px;font-size:12px;cursor:pointer">
              <option value="">Todos os vínculos</option>
              <option value="MEI">MEI</option>
              <option value="CLT">CLT</option>
            </select>
            <select id="filtro-cargo" style="background:#0d1526;border:1px solid rgba(99,179,237,.2);color:#e2e8f0;padding:5px 10px;border-radius:4px;font-size:12px;cursor:pointer">
              <option value="">Todos os cargos</option>
              <option value="PROMOTOR">Promotor</option>
              <option value="SCOUT">Scout</option>
              <option value="CHARGER">Charger</option>
              <option value="MOTORISTA">Motorista</option>
              <option value="FISCAL">Fiscal</option>
            </select>
            <select id="filtro-cidade" style="background:#0d1526;border:1px solid rgba(99,179,237,.2);color:#e2e8f0;padding:5px 10px;border-radius:4px;font-size:12px;cursor:pointer">
              <option value="">Todas as cidades</option>
            </select>
            <select id="filtro-operacao" style="background:#0d1526;border:1px solid rgba(99,179,237,.2);color:#e2e8f0;padding:5px 10px;border-radius:4px;font-size:12px;cursor:pointer">
              <option value="">Todas as operações</option>
              <option value="PROMO">PROMO</option>
              <option value="LOGISTICA">LOGISTICA</option>
            </select>
            <button id="btn-limpar-filtros" style="background:rgba(252,129,129,.1);border:1px solid rgba(252,129,129,.3);color:#fc8181;padding:5px 12px;border-radius:4px;font-size:12px;cursor:pointer">✕ Limpar</button>
            <span id="mapa-count" style="font-size:11px;color:#4a5568;margin-left:4px"></span>
            <span id="mapa-updated" style="font-size:10px;color:#4a5568;margin-left:auto;font-family:'IBM Plex Mono',monospace">--:--</span>
            <button id="btn-toggle-panel" title="Recolher/expandir painel" style="background:rgba(99,179,237,.1);border:1px solid rgba(99,179,237,.3);color:#63b3ed;padding:5px 10px;border-radius:4px;font-size:12px;cursor:pointer;margin-left:4px">⊟ Painel</button>
          </div>
        </div>

        <div id="leaflet-map" style="flex:1;min-height:0;"></div>

        <!-- Painel lateral -->
        <div id="map-panel" class="map-panel hidden">
          <button class="map-panel-close" id="btn-panel-close">✕</button>
          <div id="map-panel-content"></div>
        </div>
      </section>
    `;

    _initMap();
    _bindToggles();
    _bindFiltros();
    _load();
    _interval = setInterval(_load, CONFIG.MAP_REFRESH_INTERVAL);
    document.getElementById('btn-panel-close').addEventListener('click', _closePanel);

    // Toggle painel lateral
    let _panelVisible = false;
    document.getElementById('btn-toggle-panel').addEventListener('click', () => {
      _panelVisible = !_panelVisible;
      const panel = document.getElementById('map-panel');
      const btn   = document.getElementById('btn-toggle-panel');
      if (_panelVisible && panel) {
        panel.classList.remove('hidden');
        btn.textContent = '⊟ Painel';
      } else {
        _closePanel();
        btn.textContent = '⊞ Painel';
      }
    });
  }

  function destroy() {
    clearInterval(_interval); _interval = null;
    if (_map) { _map.remove(); _map = null; }
    _layerPromotores = _layerSlots = _layerRaios = _layerRota = null;
    _todosPromotores = []; _todosSlots = [];
  }

  // ── Leaflet ───────────────────────────────────────────────────────────────────
  function _initMap() {
    _map = L.map('leaflet-map', { zoomControl: true }).setView([-23.55052, -46.63331], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors', maxZoom: 19,
    }).addTo(_map);
    _layerPromotores = L.layerGroup().addTo(_map);
    _layerSlots      = L.layerGroup().addTo(_map);
    _layerRaios      = L.layerGroup().addTo(_map);
    _layerRota       = L.layerGroup().addTo(_map);
  }

  function _bindToggles() {
    document.querySelectorAll('.toggle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const layer = btn.dataset.layer;
        _visible[layer] = !_visible[layer];
        btn.classList.toggle('active', _visible[layer]);
        const lg = { promotores:_layerPromotores, slots:_layerSlots, raios:_layerRaios, rota:_layerRota }[layer];
        if (!lg || !_map) return;
        if (_visible[layer]) _map.addLayer(lg); else _map.removeLayer(lg);
      });
    });
  }

  function _bindFiltros() {
    const _gestor = state.get('gestor');
    if ((_gestor?.cargo || '').toUpperCase() === 'FISCAL' && _gestor?.cidade_base) {
      _filtros.cidade = _gestor.cidade_base;
      const selCidade = document.getElementById('filtro-cidade');
      if (selCidade) { selCidade.value = _gestor.cidade_base; selCidade.disabled = true; selCidade.style.opacity = '0.5'; }
    }

    ['filtro-vinculo','filtro-cargo','filtro-cidade','filtro-operacao'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', e => {
        const key = id.replace('filtro-', '');
        _filtros[key] = e.target.value;
        _aplicarFiltros();
      });
    });
    document.getElementById('btn-limpar-filtros')?.addEventListener('click', () => {
      ['filtro-vinculo','filtro-cargo','filtro-cidade','filtro-operacao'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
      });
      Object.keys(_filtros).forEach(k => _filtros[k] = '');
      _aplicarFiltros();
    });
  }

  // ── Carga de dados ───────────────────────────────────────────────────────────
  async function _load() {
    // Atualiza indicador
    const updEl = document.getElementById('mapa-updated');
    if (updEl) updEl.textContent = new Date().toLocaleTimeString('pt-BR', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
    try {
      const [promRes, slotsRes] = await Promise.all([
        api.getPromotoresAtivos(),
        api.getSlotsHoje(),
      ]);

      _todosPromotores = promRes?.data || [];
      _todosSlots      = slotsRes?.data || [];

      // Popular select de cidades dinamicamente
      _popularCidades();
      _aplicarFiltros();

      const now = new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
      const el = document.getElementById('mapa-updated');
      if (el) el.textContent = `Atualizado ${now}`;

    } catch (err) {
      console.error('[Mapa] Erro:', err);
    }
  }

  function _popularCidades() {
    const sel = document.getElementById('filtro-cidade');
    if (!sel) return;
    const cidades = [...new Set([
      ..._todosPromotores.map(p => p.cidade).filter(Boolean),
      ..._todosSlots.map(s => s.cidade).filter(Boolean),
    ])].sort();
    const atual = sel.value;
    sel.innerHTML = '<option value="">Todas as cidades</option>' +
      cidades.map(c => `<option value="${c}" ${c===atual?'selected':''}>${c}</option>`).join('');
  }

  function _aplicarFiltros() {
    const filtrados = _todosPromotores.filter(p => {
      if (_filtros.vinculo  && (p.tipo_vinculo||'').toUpperCase() !== _filtros.vinculo)  return false;
      if (_filtros.cargo    && (p.cargo_principal||p.cargo_clt||'').toUpperCase() !== _filtros.cargo) return false;
      if (_filtros.cidade   && (p.cidade||'') !== _filtros.cidade)   return false;
      if (_filtros.operacao && (p.operacao||'') !== _filtros.operacao) return false;
      return true;
    });

    _renderPromotores(filtrados);
    _renderSlots(_todosSlots);

    const countEl = document.getElementById('mapa-count');
    if (countEl) {
      const total = _todosPromotores.length;
      const vis   = filtrados.filter(p => p.lat && p.lng).length;
      countEl.textContent = `${vis} no mapa / ${filtrados.length} filtrados / ${total} total`;
    }
  }

  // ── Renderiza promotores ─────────────────────────────────────────────────────
  function _renderPromotores(lista) {
    if (!_layerPromotores) return;
    _layerPromotores.clearLayers();

    lista.forEach(p => {
      if (!p.lat || !p.lng) return;

      const vinculo = (p.tipo_vinculo || 'MEI').toUpperCase();
      const cor     = _corPorStatus(p.status_jornada);
      const emoji   = vinculo === 'CLT' ? '⚙️' : '👤';

      const primeiroNome = (p.nome || '').split(' ')[0].substring(0, 10);
      const icon = L.divIcon({
        className: '',
        html: `<div style="display:flex;flex-direction:column;align-items:center;gap:2px;cursor:pointer">
          <div style="
            width:38px;height:38px;border-radius:50%;
            background:${cor};border:3px solid white;
            display:flex;align-items:center;justify-content:center;
            font-size:16px;box-shadow:0 2px 8px rgba(0,0,0,0.4);
          ">${emoji}</div>
          <div style="
            background:rgba(13,21,38,0.85);color:#eaf0fb;
            font-size:10px;font-weight:700;padding:2px 5px;
            border-radius:4px;white-space:nowrap;
            box-shadow:0 1px 4px rgba(0,0,0,0.4);
            border:1px solid rgba(99,179,237,0.2);
          ">${primeiroNome}</div>
        </div>`,
        iconSize: [38,52], iconAnchor: [19,52],
      });

      L.marker([p.lat, p.lng], { icon })
        .on('click', () => _showPromotorPanel(p))
        .addTo(_layerPromotores);
    });
  }

  // ── Renderiza slots ──────────────────────────────────────────────────────────
  function _renderSlots(lista) {
    if (!_layerSlots || !_layerRaios) return;
    _layerSlots.clearLayers();
    _layerRaios.clearLayers();

    // Aplicar filtro de cidade nos slots também
    const filtrados = lista.filter(s => {
      if (_filtros.cidade && s.cidade !== _filtros.cidade) return false;
      return true;
    });

    filtrados.forEach(s => {
      if (!s.lat || !s.lng) return;
      const ocupado = s.status === 'OCUPADO';
      const cor = ocupado ? '#fc8181' : '#68d391';

      const primeiroNomeSlot = ocupado && s.promotor_nome ? s.promotor_nome.split(' ')[0].substring(0,10) : '';
      const icon = L.divIcon({
        className: '',
        html: `<div style="display:flex;flex-direction:column;align-items:center;gap:2px">
          <div style="
            width:30px;height:30px;border-radius:4px;
            background:${cor};border:2px solid white;
            display:flex;align-items:center;justify-content:center;
            font-size:14px;box-shadow:0 2px 6px rgba(0,0,0,0.4);cursor:pointer;
          ">📍</div>
          ${primeiroNomeSlot ? `<div style="font-size:10px;font-weight:700;color:white;background:rgba(0,0,0,.6);padding:1px 4px;border-radius:3px;white-space:nowrap">${primeiroNomeSlot}</div>` : ''}
        </div>`,
        iconSize: [30, primeiroNomeSlot ? 46 : 30], iconAnchor: [15,15],
      });

      L.marker([s.lat, s.lng], { icon })
        .on('click', () => _showSlotPanel(s))
        .addTo(_layerSlots);

      if (s.raio_metros) {
        L.circle([s.lat, s.lng], {
          radius: s.raio_metros, color: cor,
          fillColor: cor, fillOpacity: 0.08, weight: 1.5,
        }).addTo(_layerRaios);
      }
    });
  }

  // ── Painel: promotor ─────────────────────────────────────────────────────────
  function _showPromotorPanel(p) {
    const content  = document.getElementById('map-panel-content');
    const elapsed  = p.inicio_real ? _elapsed(p.inicio_real) : '—';
    const vinculo  = (p.tipo_vinculo || 'MEI').toUpperCase();
    const cargo    = p.cargo_principal || p.cargo_clt || '—';
    const corVinc  = vinculo === 'CLT' ? '#f6ad55' : '#63b3ed';

    content.innerHTML = `
      <div class="panel-section">
        <div class="panel-name">${p.nome}</div>
        <div class="panel-sub">${cargo}</div>
        <div style="display:flex;gap:6px;margin-top:4px">
          <span class="status-badge" style="background:${corVinc}20;color:${corVinc};border-color:${corVinc}40">${vinculo}</span>
          <span class="status-badge" style="background:${_corPorStatus(p.status_jornada)}20;color:${_corPorStatus(p.status_jornada)};border-color:${_corPorStatus(p.status_jornada)}40">
            ${p.status_jornada || 'Ativo'}
          </span>
        </div>
      </div>

      <div class="panel-row"><span>Cidade</span><strong>${p.cidade || '—'}</strong></div>
      <div class="panel-row"><span>Operação</span><strong>${p.operacao || '—'}</strong></div>
      <div class="panel-row"><span>Slot / Turno</span><strong>${p.slot_nome || p.slot_id || '—'}</strong></div>
      <div class="panel-row"><span>Em campo há</span><strong>${elapsed}</strong></div>
      <div class="panel-row"><span>Última posição</span><strong>${p.ultima_posicao ? _fmtTs(p.ultima_posicao) : '—'}</strong></div>
      <div class="panel-row"><span>Trust score</span><strong>${p.location_trust_score ?? '—'}</strong></div>

      <button class="panel-btn" id="btn-ver-rota">🛣️ Ver rota de hoje</button>
    `;

    _openPanel();

    document.getElementById('btn-ver-rota').addEventListener('click', () => _loadRota(p.promotor_id || p.user_id));
    if (_map && p.lat && p.lng) _map.setView([p.lat, p.lng], 15, { animate: true });
  }

  // ── Painel: slot ─────────────────────────────────────────────────────────────
  function _showSlotPanel(s) {
    const content = document.getElementById('map-panel-content');
    const ocupado = s.status === 'OCUPADO';

    content.innerHTML = `
      <div class="panel-section">
        <div class="panel-name">${s.nome || s.slot_id}</div>
        <div class="panel-sub">${s.cidade || ''}</div>
        <span class="status-badge" style="
          background:${ocupado?'#fc818120':'#68d39120'};
          color:${ocupado?'#fc8181':'#68d391'};
          border-color:${ocupado?'#fc818140':'#68d39140'};
        ">${ocupado ? (s.checkin_hora ? '⚡ Em atividade' : '⏳ Aceito — a caminho') : 'Disponível'}</span>
      </div>
      <div class="panel-row"><span>Raio</span><strong>${s.raio_metros}m</strong></div>
      <div class="panel-row"><span>Promotor</span><strong>${s.promotor_nome || '—'}</strong></div>
      <div class="panel-row"><span>Horário</span><strong>${s.inicio_slot||'—'} – ${s.fim_slot||'—'}</strong></div>
    `;

    _openPanel();
    if (_map && s.lat && s.lng) _map.setView([s.lat, s.lng], 15, { animate: true });
  }

  // ── Rota histórica ───────────────────────────────────────────────────────────
  async function _loadRota(promotorId) {
    if (!_layerRota || !_map) return;
    _layerRota.clearLayers();

    try {
      const hoje = new Date().toISOString().slice(0,10);
      const res  = await api.getHistoricoLocalizacao(promotorId, hoje);
      const pontos = res?.data || [];

      if (!pontos.length) { alert('Sem histórico de localização para hoje.'); return; }

      const latlngs = pontos.map(p => [p.lat, p.lng]);
      L.polyline(latlngs, { color:'#63b3ed', weight:3, opacity:0.8, dashArray:'6,4' }).addTo(_layerRota);
      L.circleMarker(latlngs[0], { radius:7, color:'#68d391', fillColor:'#68d391', fillOpacity:1, weight:2 }).bindTooltip('Início').addTo(_layerRota);
      L.circleMarker(latlngs[latlngs.length-1], { radius:7, color:'#fc8181', fillColor:'#fc8181', fillOpacity:1, weight:2 }).bindTooltip('Atual').addTo(_layerRota);
      _map.fitBounds(L.latLngBounds(latlngs), { padding:[40,40] });

      if (!_visible.rota) {
        _visible.rota = true;
        _map.addLayer(_layerRota);
        document.querySelector('[data-layer="rota"]')?.classList.add('active');
      }
    } catch (err) { console.error('[Mapa] Rota:', err); }
  }

  // ── Helpers ──────────────────────────────────────────────────────────────────
  function _corPorStatus(status) {
    return { EM_OPERACAO:'#68d391', EM_ATIVIDADE:'#68d391', PAUSADO:'#f6ad55', CHECKIN_FEITO:'#63b3ed', EM_ANDAMENTO:'#f6ad55' }[status] || '#718096';
  }

  function _elapsed(isoStr) {
    const diff = Math.floor((Date.now() - new Date(isoStr)) / 60000);
    return diff < 60 ? `${diff}min` : `${Math.floor(diff/60)}h${String(diff%60).padStart(2,'0')}`;
  }

  function _fmtTs(v) {
    if (!v) return '—';
    try { return new Date(v).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}); }
    catch(_) { return '—'; }
  }

  function _openPanel()  { document.getElementById('map-panel')?.classList.remove('hidden'); }
  function _closePanel() { document.getElementById('map-panel')?.classList.add('hidden'); }

  return { render, destroy };
})();